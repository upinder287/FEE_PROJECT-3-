const Services = () => {
  return (
    <>
      <div id="services" className="services_section layout_padding">
        <div className="container">
          <h1 className="services_taital">our services</h1>
          <p className="many_taital">
            There are many variations of passages of Lorem Ipsum{" "}
          </p>
          <div className="services_section2 layout_padding">
            <div className="row">
              <div className="col-lg-3 col-sm-6">
                <div className="icon_1">
                  <img src="images/icon-1.png" alt="Furniture Icon" />
                </div>
                <h2 className="furnitures_text">Furnitures</h2>
                <p className="dummy_text">
                  There are many variations of passages of Lorem Ipsum
                  available, but the
                </p>
                <div className="read_bt_main">
                  <div className="read_bt">
                    <a href="#">Read More</a>
                  </div>
                </div>
              </div>
              <div className="col-lg-3 col-sm-6">
                <div className="icon_1">
                  <img src="images/icon-2.png" alt="Office Icon" />
                </div>
                <h2 className="furnitures_text">Office</h2>
                <p className="dummy_text">
                  There are many variations of passages of Lorem Ipsum
                  available, but the
                </p>
                <div className="read_bt_main">
                  <div className="read_bt">
                    <a href="#">Read More</a>
                  </div>
                </div>
              </div>
              <div className="col-lg-3 col-sm-6">
                <div className="icon_1">
                  <img src="images/icon-3.png" alt="Home Icon" />
                </div>
                <h2 className="furnitures_text">Home</h2>
                <p className="dummy_text">
                  There are many variations of passages of Lorem Ipsum
                  available, but the
                </p>
                <div className="read_bt_main">
                  <div className="read_bt">
                    <a href="#">Read More</a>
                  </div>
                </div>
              </div>
              <div className="col-lg-3 col-sm-6">
                <div className="icon_1">
                  <img src="images/icon-4.png" alt="Bedroom Icon" />
                </div>
                <h2 className="furnitures_text">Bedroom</h2>
                <p className="dummy_text">
                  There are many variations of passages of Lorem Ipsum
                  available, but the
                </p>
                <div className="read_bt_main">
                  <div className="read_bt">
                    <a href="#">Read More</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Services;
